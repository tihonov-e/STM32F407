#include "stm32f4xx.h"

int main () {
    while(1){}
 }
 
 //работающий шаблон